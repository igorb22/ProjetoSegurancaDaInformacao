﻿namespace SeguradosAPI.Models
{
    public class TematicaModel
    {
        public int IdTematica { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
    }
}
